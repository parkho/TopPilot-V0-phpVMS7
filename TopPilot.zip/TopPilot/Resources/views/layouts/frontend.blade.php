{{--
You probably don't want to edit anything here. Just make
sure to extend this in your views. It will pass the content section through
--}}
@extends('app')
